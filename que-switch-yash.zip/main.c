#include <stdio.h>
#include<stdlib.h>
int main()

{ 
    int choice;
     int que[10],i,n,f,r,x,ch;
     r=f=-1;
    printf("\n enter the size of que");
    scanf("%d",&n);
    while(1)
    {
        printf("\n 1.push  \n 2.pop \n 3.peek \n 4.display ");
        printf(" \nenter the choice");
        scanf( "%d",&choice);
        switch(choice)
        {
         
          case 1:  //Enqueue
          
          printf("enter the element:");
          scanf("%d",&x);
          if(r==n-1){
              printf("overflow");
          }
          else if (f==-1&&r==-1){
              f=r=0;
              que[r]=x;
          }
          else{
              r++;
              que[r]=x;
          }
          break;
          
          
          case 2:   //Dequeue
         
          if(f==-1 && r==-1)
          {
              printf("underflow");
          }
          else if (f==r)
          {
              printf("\n element deleted from que %d:", que[f]);
              f=r=-1;
          }
          else
          {
               printf("\n element deleted from que %d", que[f]);
               f++;
            
          }
          break;
          case 3://show
          for(i=f;i<=r;i++)
          {
              printf("\n elements are %d",que[i]);
              
          }
          break;
          
          case 4:
       
          exit(0);
          
          break;
        }
        
    }

    return 0;
}